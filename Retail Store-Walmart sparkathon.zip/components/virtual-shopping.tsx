"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Gamepad2, ShoppingBag, Sparkles, Users, Zap } from "lucide-react"

const virtualPlatforms = [
  {
    name: "Roblox",
    icon: "🎮",
    users: "70M+ daily users",
    description: "Shop for virtual and real-world items in popular games",
  },
  {
    name: "ZEPETO",
    icon: "👤",
    users: "400M+ registered",
    description: "Customize avatars and buy matching real-world fashion",
  },
  {
    name: "Unity Games",
    icon: "🎯",
    users: "3B+ devices",
    description: "Integrated shopping in Unity-powered experiences",
  },
]

const virtualProducts = [
  {
    id: 1,
    name: "No Boundaries Hoodie",
    virtualPrice: 50,
    realPrice: 24.99,
    platform: "ZEPETO",
    category: "Fashion",
    bundleDiscount: 15,
  },
  {
    id: 2,
    name: "Gaming Chair",
    virtualPrice: 200,
    realPrice: 149.99,
    platform: "Roblox",
    category: "Furniture",
    bundleDiscount: 20,
  },
  {
    id: 3,
    name: "Sneakers Collection",
    virtualPrice: 75,
    realPrice: 39.99,
    platform: "ZEPETO",
    category: "Footwear",
    bundleDiscount: 10,
  },
]

export function VirtualShopping() {
  const [selectedPlatform, setSelectedPlatform] = useState("ZEPETO")
  const [showBundleOffer, setShowBundleOffer] = useState(false)

  const handleVirtualPurchase = (product: any) => {
    setShowBundleOffer(true)
  }

  return (
    <div className="space-y-6">
      {/* Platform Selection */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Gamepad2 className="w-5 h-5" />
            Virtual Shopping Platforms
          </CardTitle>
          <CardDescription>Shop in virtual worlds and buy real products with Immersive Commerce APIs</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {virtualPlatforms.map((platform) => (
              <Card
                key={platform.name}
                className={`cursor-pointer transition-all ${selectedPlatform === platform.name ? "ring-2 ring-blue-500 bg-blue-50" : "hover:shadow-md"}`}
                onClick={() => setSelectedPlatform(platform.name)}
              >
                <CardContent className="p-4 text-center">
                  <div className="text-3xl mb-2">{platform.icon}</div>
                  <h3 className="font-semibold mb-1">{platform.name}</h3>
                  <Badge variant="secondary" className="mb-2">
                    {platform.users}
                  </Badge>
                  <p className="text-sm text-gray-600">{platform.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Virtual Store */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5" />
            {selectedPlatform} Virtual Store
          </CardTitle>
          <CardDescription>Virtual items that can be purchased as real products</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {virtualProducts
              .filter((product) => product.platform === selectedPlatform)
              .map((product) => (
                <Card key={product.id} className="overflow-hidden">
                  <div className="relative">
                    <img
                      src="/placeholder.svg?height=200&width=200"
                      alt={product.name}
                      className="w-full h-48 object-cover"
                    />
                    <Badge className="absolute top-2 left-2 bg-purple-500">Virtual + Real</Badge>
                  </div>
                  <CardContent className="p-4">
                    <h3 className="font-semibold mb-2">{product.name}</h3>
                    <div className="space-y-2 mb-4">
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-600">Virtual Price:</span>
                        <span className="font-medium">{product.virtualPrice} coins</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-600">Real Price:</span>
                        <span className="font-medium">${product.realPrice}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-600">Bundle Discount:</span>
                        <span className="font-medium text-green-600">{product.bundleDiscount}% off</span>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Button
                        className="w-full bg-transparent"
                        variant="outline"
                        onClick={() => handleVirtualPurchase(product)}
                      >
                        Buy Virtual Item
                      </Button>
                      <Button className="w-full">Buy Real Product - ${product.realPrice}</Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
          </div>
        </CardContent>
      </Card>

      {/* Bundle Offer Modal */}
      {showBundleOffer && (
        <Card className="border-2 border-green-500 bg-green-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-green-800">
              <Sparkles className="w-5 h-5" />
              Special Bundle Offer!
            </CardTitle>
            <CardDescription className="text-green-700">
              You just bought a virtual item - get the real version at a discount!
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-white p-4 rounded-lg">
              <h4 className="font-semibold mb-2">Bundle Deal:</h4>
              <div className="space-y-1">
                <p className="text-sm">✅ Virtual No Boundaries Hoodie (purchased)</p>
                <p className="text-sm">🛍️ Real No Boundaries Hoodie</p>
                <p className="text-sm text-green-600">💰 Save 15% on real item!</p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button className="flex-1">
                <Zap className="w-4 h-4 mr-2" />
                Buy Bundle - $21.24
              </Button>
              <Button variant="outline" onClick={() => setShowBundleOffer(false)}>
                Maybe Later
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Social Shopping */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="w-5 h-5" />
            Social Shopping Features
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h4 className="font-semibold">Friend Recommendations</h4>
              <div className="space-y-2">
                <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                  <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-sm">
                    A
                  </div>
                  <div>
                    <p className="text-sm font-medium">Alex bought this hoodie</p>
                    <p className="text-xs text-gray-600">2 hours ago</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                  <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center text-white text-sm">
                    S
                  </div>
                  <div>
                    <p className="text-sm font-medium">Sarah liked this chair</p>
                    <p className="text-xs text-gray-600">1 day ago</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="font-semibold">Virtual Try-On Parties</h4>
              <div className="space-y-2">
                <Button variant="outline" className="w-full justify-start bg-transparent">
                  🎉 Join Fashion Show (3 friends online)
                </Button>
                <Button variant="outline" className="w-full justify-start bg-transparent">
                  🏠 Home Decor Planning Session
                </Button>
                <Button variant="outline" className="w-full justify-start bg-transparent">
                  🎮 Gaming Setup Showcase
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Platform Integration */}
      <Card>
        <CardHeader>
          <CardTitle>Immersive Commerce Integration</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <h4 className="font-semibold">Cross-Platform Shopping</h4>
              <p className="text-sm text-gray-600">Seamless experience across Roblox, ZEPETO, Unity, and more</p>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold">Virtual-to-Real Commerce</h4>
              <p className="text-sm text-gray-600">Buy virtual items and get discounts on real-world versions</p>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold">Social Shopping</h4>
              <p className="text-sm text-gray-600">Shop with friends, share recommendations, and join virtual events</p>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold">Gamified Experience</h4>
              <p className="text-sm text-gray-600">Earn rewards, unlock exclusive items, and level up your shopping</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
