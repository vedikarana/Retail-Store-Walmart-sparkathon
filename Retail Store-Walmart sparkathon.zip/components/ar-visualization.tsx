"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Camera, RotateCcw, Maximize, Info, Star, ShoppingCart, Palette } from "lucide-react"

const arProducts = [
  {
    id: 1,
    name: "Modern 3-Seat Sofa",
    price: 449.99,
    colors: ["Navy Blue", "Charcoal Gray", "Beige"],
    dimensions: '78" W x 32" D x 34" H',
    rating: 4.5,
    reviews: 234,
  },
]

const hotspots = [
  { x: 30, y: 40, type: "info", content: "Premium fabric - stain resistant" },
  { x: 60, y: 30, type: "color", content: "Available in 3 colors" },
  { x: 45, y: 70, type: "review", content: "4.5/5 stars - 234 reviews" },
  { x: 20, y: 60, type: "dimension", content: "Perfect for small spaces" },
]

export function ARVisualization() {
  const [isARActive, setIsARActive] = useState(false)
  const [selectedColor, setSelectedColor] = useState("Navy Blue")
  const [showHotspots, setShowHotspots] = useState(true)
  const [selectedHotspot, setSelectedHotspot] = useState<any>(null)

  const startAR = () => {
    setIsARActive(true)
  }

  const stopAR = () => {
    setIsARActive(false)
    setSelectedHotspot(null)
  }

  return (
    <div className="space-y-6">
      {/* AR Controls */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Camera className="w-5 h-5" />
            Retina AR Visualization
          </CardTitle>
          <CardDescription>See how products look in your space with interactive hotspots</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4">
            <Button onClick={isARActive ? stopAR : startAR} className={isARActive ? "bg-red-500 hover:bg-red-600" : ""}>
              <Camera className="w-4 h-4 mr-2" />
              {isARActive ? "Stop AR" : "Start AR View"}
            </Button>
            {isARActive && (
              <>
                <Button variant="outline" onClick={() => setShowHotspots(!showHotspots)}>
                  <Info className="w-4 h-4 mr-2" />
                  {showHotspots ? "Hide" : "Show"} Hotspots
                </Button>
                <Button variant="outline">
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Rotate
                </Button>
                <Button variant="outline">
                  <Maximize className="w-4 h-4 mr-2" />
                  Fullscreen
                </Button>
              </>
            )}
          </div>
        </CardContent>
      </Card>

      {/* AR View */}
      {isARActive ? (
        <Card className="overflow-hidden">
          <CardContent className="p-0">
            <div className="relative bg-gradient-to-b from-gray-100 to-gray-200 h-96 flex items-center justify-center">
              {/* Simulated AR Environment */}
              <div className="relative">
                <img
                  src="/placeholder.svg?height=300&width=400"
                  alt="Living room with AR furniture"
                  className="rounded-lg shadow-lg"
                />

                {/* Interactive Hotspots */}
                {showHotspots &&
                  hotspots.map((hotspot, index) => (
                    <button
                      key={index}
                      className="absolute w-6 h-6 bg-blue-500 rounded-full border-2 border-white shadow-lg animate-pulse hover:scale-110 transition-transform"
                      style={{ left: `${hotspot.x}%`, top: `${hotspot.y}%` }}
                      onClick={() => setSelectedHotspot(hotspot)}
                    >
                      <span className="sr-only">Hotspot {index + 1}</span>
                    </button>
                  ))}

                {/* Hotspot Tooltip */}
                {selectedHotspot && (
                  <div
                    className="absolute bg-white p-3 rounded-lg shadow-lg border max-w-xs z-10"
                    style={{
                      left: `${selectedHotspot.x}%`,
                      top: `${selectedHotspot.y - 10}%`,
                      transform: "translateX(-50%) translateY(-100%)",
                    }}
                  >
                    <p className="text-sm font-medium">{selectedHotspot.content}</p>
                    <button
                      className="absolute -top-2 -right-2 w-6 h-6 bg-gray-200 rounded-full text-xs"
                      onClick={() => setSelectedHotspot(null)}
                    >
                      ×
                    </button>
                  </div>
                )}
              </div>

              {/* AR Status */}
              <div className="absolute top-4 left-4">
                <Badge className="bg-green-500">AR Active - Retina Powered</Badge>
              </div>

              {/* AR Instructions */}
              <div className="absolute bottom-4 left-4 right-4">
                <Card className="bg-black/80 text-white">
                  <CardContent className="p-3">
                    <p className="text-sm">
                      📱 Move your device to explore • 👆 Tap hotspots for details • 🎨 Change colors below
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </CardContent>
        </Card>
      ) : (
        <Card className="border-dashed border-2 border-gray-300">
          <CardContent className="flex flex-col items-center justify-center h-96 text-center">
            <Camera className="w-16 h-16 text-gray-400 mb-4" />
            <h3 className="text-xl font-semibold mb-2">AR View Not Active</h3>
            <p className="text-gray-600 mb-4">Start AR to see products in your space</p>
            <Button onClick={startAR}>
              <Camera className="w-4 h-4 mr-2" />
              Start AR Experience
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Product Customization */}
      {isARActive && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Palette className="w-5 h-5" />
              Customize Your Product
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h4 className="font-semibold mb-2">Color Options</h4>
              <div className="flex gap-2">
                {arProducts[0].colors.map((color) => (
                  <Button
                    key={color}
                    variant={selectedColor === color ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedColor(color)}
                  >
                    {color}
                  </Button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <h4 className="font-semibold mb-1">Dimensions</h4>
                <p className="text-sm text-gray-600">{arProducts[0].dimensions}</p>
              </div>
              <div>
                <h4 className="font-semibold mb-1">Rating</h4>
                <div className="flex items-center gap-1">
                  <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  <span className="text-sm">
                    {arProducts[0].rating} ({arProducts[0].reviews} reviews)
                  </span>
                </div>
              </div>
            </div>

            <div className="flex gap-2">
              <Button className="flex-1">
                <ShoppingCart className="w-4 h-4 mr-2" />
                Add to Cart - ${arProducts[0].price}
              </Button>
              <Button variant="outline">Share AR View</Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* AR Features */}
      <Card>
        <CardHeader>
          <CardTitle>AR Visualization Features</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <h4 className="font-semibold">Real-time 3D Rendering</h4>
              <p className="text-sm text-gray-600">
                Powered by Retina's AI and automation for instant 3D asset generation
              </p>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold">Interactive Hotspots</h4>
              <p className="text-sm text-gray-600">Tap to see product details, reviews, and complementary items</p>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold">Scale & Placement</h4>
              <p className="text-sm text-gray-600">Accurate sizing and positioning in your actual space</p>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold">Color & Material Preview</h4>
              <p className="text-sm text-gray-600">See different options in real-time with realistic lighting</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
