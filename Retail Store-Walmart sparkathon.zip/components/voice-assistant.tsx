"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Mic, MicOff, Volume2, Search, Sparkles } from "lucide-react"

const voiceCommands = [
  "Find me a couch for my small living room under $500",
  "I need a gift for a 10-year-old's birthday",
  "Show me winter jackets in size medium",
  "Reorder my usual groceries",
  "What's trending in home decor?",
]

const mockResponses = {
  "Find me a couch for my small living room under $500": {
    text: "I found 12 couches perfect for small living rooms under $500. The top recommendation is a Modern 3-Seat Sofa for $449.99, which has excellent reviews and fits spaces as small as 10x12 feet. Would you like to see it in AR?",
    products: [
      { name: "Modern 3-Seat Sofa", price: 449.99, rating: 4.5 },
      { name: "Compact Loveseat", price: 299.99, rating: 4.3 },
      { name: "Sectional Sofa", price: 479.99, rating: 4.6 },
    ],
  },
  "I need a gift for a 10-year-old's birthday": {
    text: "Great! For a 10-year-old, I recommend these trending items: LEGO sets, art supplies, or the latest gaming accessories. Based on current trends, the LEGO Creator 3-in-1 Deep Sea Creatures set is very popular. What's your budget?",
    products: [
      { name: "LEGO Creator 3-in-1", price: 79.99, rating: 4.8 },
      { name: "Art Set Deluxe", price: 34.99, rating: 4.4 },
      { name: "Nintendo Switch Game", price: 59.99, rating: 4.7 },
    ],
  },
}

export function VoiceAssistant() {
  const [isListening, setIsListening] = useState(false)
  const [currentCommand, setCurrentCommand] = useState("")
  const [response, setResponse] = useState<any>(null)
  const [isProcessing, setIsProcessing] = useState(false)

  const startListening = () => {
    setIsListening(true)
    setCurrentCommand("")
    setResponse(null)
  }

  const stopListening = () => {
    setIsListening(false)
    if (currentCommand) {
      processCommand(currentCommand)
    }
  }

  const processCommand = (command: string) => {
    setIsProcessing(true)
    setTimeout(() => {
      const mockResponse = mockResponses[command as keyof typeof mockResponses] || {
        text: "I understand you're looking for something. Let me search our catalog and find the best options for you.",
        products: [],
      }
      setResponse(mockResponse)
      setIsProcessing(false)
    }, 2000)
  }

  const tryCommand = (command: string) => {
    setCurrentCommand(command)
    processCommand(command)
  }

  return (
    <div className="space-y-6">
      {/* Voice Interface */}
      <Card className="text-center">
        <CardHeader>
          <CardTitle className="flex items-center justify-center gap-2">
            <Mic className="w-5 h-5" />
            Wallaby AI Voice Assistant
          </CardTitle>
          <CardDescription>
            Speak naturally to find products, get recommendations, and complete purchases
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex justify-center">
            <Button
              size="lg"
              className={`w-32 h-32 rounded-full ${isListening ? "bg-red-500 hover:bg-red-600 animate-pulse" : "bg-blue-600 hover:bg-blue-700"}`}
              onClick={isListening ? stopListening : startListening}
            >
              {isListening ? <MicOff className="w-12 h-12" /> : <Mic className="w-12 h-12" />}
            </Button>
          </div>

          <div className="space-y-2">
            {isListening && (
              <Badge variant="secondary" className="bg-red-100 text-red-800">
                Listening... Speak now
              </Badge>
            )}
            {isProcessing && (
              <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                Processing with Wallaby AI...
              </Badge>
            )}
          </div>

          {currentCommand && (
            <Card className="bg-gray-50">
              <CardContent className="p-4">
                <p className="text-sm font-medium">You said:</p>
                <p className="text-lg">"{currentCommand}"</p>
              </CardContent>
            </Card>
          )}
        </CardContent>
      </Card>

      {/* Try Sample Commands */}
      <Card>
        <CardHeader>
          <CardTitle>Try These Voice Commands</CardTitle>
          <CardDescription>Click any command to see how Wallaby AI responds</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3">
            {voiceCommands.map((command, index) => (
              <Button
                key={index}
                variant="outline"
                className="justify-start h-auto p-4 text-left bg-transparent"
                onClick={() => tryCommand(command)}
              >
                <div className="flex items-center gap-3">
                  <Volume2 className="w-4 h-4 text-blue-600" />
                  <span>"{command}"</span>
                </div>
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* AI Response */}
      {response && (
        <Card className="border-blue-200 bg-blue-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-blue-600" />
              Wallaby AI Response
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-lg">{response.text}</p>

            {response.products.length > 0 && (
              <div className="space-y-3">
                <h4 className="font-semibold">Recommended Products:</h4>
                <div className="grid gap-3">
                  {response.products.map((product: any, index: number) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-white rounded-lg">
                      <div>
                        <h5 className="font-medium">{product.name}</h5>
                        <p className="text-sm text-gray-600">Rating: {product.rating}/5</p>
                      </div>
                      <div className="text-right">
                        <p className="font-bold">${product.price}</p>
                        <Button size="sm" className="mt-1">
                          View
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="flex gap-2">
              <Button>
                <Search className="w-4 h-4 mr-2" />
                View All Results
              </Button>
              <Button variant="outline">Try AR View</Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Features */}
      <Card>
        <CardHeader>
          <CardTitle>Voice Assistant Features</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <h4 className="font-semibold">Natural Language Processing</h4>
              <p className="text-sm text-gray-600">
                Understands context, preferences, and intent using Walmart's proprietary Wallaby LLM
              </p>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold">Contextual Recommendations</h4>
              <p className="text-sm text-gray-600">
                Factors in location, weather, purchase history, and current trends
              </p>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold">Multi-turn Conversations</h4>
              <p className="text-sm text-gray-600">Maintains context across multiple questions and refinements</p>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold">Voice Commerce</h4>
              <p className="text-sm text-gray-600">
                Complete purchases, reorder items, and manage cart with voice commands
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
