"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { CreditCard, Mic, Zap, CheckCircle, Clock, ShoppingCart } from "lucide-react"

const cartItems = [
  {
    id: 1,
    name: "Modern 3-Seat Sofa",
    price: 449.99,
    quantity: 1,
    image: "/placeholder.svg?height=80&width=80",
  },
  {
    id: 2,
    name: "Tide Laundry Detergent",
    price: 12.97,
    quantity: 2,
    image: "/placeholder.svg?height=80&width=80",
    predictive: true,
  },
]

const predictiveReorders = [
  {
    id: 3,
    name: "Milk - 2% Reduced Fat",
    price: 3.48,
    quantity: 1,
    nextOrderDate: "in 3 days",
    confidence: 95,
  },
  {
    id: 4,
    name: "Bread - Whole Wheat",
    price: 2.98,
    quantity: 1,
    nextOrderDate: "in 5 days",
    confidence: 87,
  },
]

export function CheckoutFlow() {
  const [checkoutStep, setCheckoutStep] = useState("cart")
  const [isVoiceActive, setIsVoiceActive] = useState(false)
  const [orderComplete, setOrderComplete] = useState(false)

  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0)
  const tax = subtotal * 0.13 // 13% tax for Canada
  const total = subtotal + tax

  const handleVoiceCheckout = () => {
    setIsVoiceActive(true)
    setTimeout(() => {
      setIsVoiceActive(false)
      setOrderComplete(true)
    }, 3000)
  }

  const handleQuickCheckout = () => {
    setOrderComplete(true)
  }

  if (orderComplete) {
    return (
      <Card className="text-center">
        <CardContent className="p-8">
          <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-2">Order Confirmed! 🎉</h2>
          <p className="text-gray-600 mb-4">Your order will be delivered in 2-3 business days</p>
          <Badge className="bg-green-100 text-green-800 mb-4">Order #WM-2025-001234</Badge>
          <div className="space-y-2">
            <Button className="w-full">Track Your Order</Button>
            <Button
              variant="outline"
              className="w-full bg-transparent"
              onClick={() => {
                setOrderComplete(false)
                setCheckoutStep("cart")
              }}
            >
              Continue Shopping
            </Button>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      {/* Cart Summary */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ShoppingCart className="w-5 h-5" />
            Your Cart
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {cartItems.map((item) => (
            <div key={item.id} className="flex items-center gap-4 p-4 border rounded-lg">
              <img src={item.image || "/placeholder.svg"} alt={item.name} className="w-16 h-16 object-cover rounded" />
              <div className="flex-1">
                <h4 className="font-medium">{item.name}</h4>
                <p className="text-sm text-gray-600">Quantity: {item.quantity}</p>
                {item.predictive && (
                  <Badge variant="secondary" className="mt-1 bg-orange-100 text-orange-800">
                    Predictive Reorder
                  </Badge>
                )}
              </div>
              <div className="text-right">
                <p className="font-bold">${(item.price * item.quantity).toFixed(2)}</p>
              </div>
            </div>
          ))}

          <div className="border-t pt-4 space-y-2">
            <div className="flex justify-between">
              <span>Subtotal:</span>
              <span>${subtotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span>Tax:</span>
              <span>${tax.toFixed(2)}</span>
            </div>
            <div className="flex justify-between font-bold text-lg">
              <span>Total:</span>
              <span>${total.toFixed(2)}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Predictive Reorders */}
      <Card className="border-orange-200 bg-orange-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-orange-600" />
            Suggested Reorders
          </CardTitle>
          <CardDescription>AI predicts you'll need these items soon</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {predictiveReorders.map((item) => (
            <div key={item.id} className="flex items-center justify-between p-3 bg-white rounded-lg">
              <div>
                <h4 className="font-medium">{item.name}</h4>
                <p className="text-sm text-gray-600">Usually needed {item.nextOrderDate}</p>
                <Badge variant="secondary" className="mt-1">
                  {item.confidence}% confidence
                </Badge>
              </div>
              <div className="text-right">
                <p className="font-bold">${item.price}</p>
                <Button size="sm" variant="outline" className="mt-1 bg-transparent">
                  Add to Cart
                </Button>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Checkout Options */}
      <Card>
        <CardHeader>
          <CardTitle>Frictionless Checkout</CardTitle>
          <CardDescription>Complete your purchase with voice commands or one-tap checkout</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Voice Checkout */}
          <Card className="border-blue-200 bg-blue-50">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-semibold flex items-center gap-2">
                  <Mic className="w-4 h-4" />
                  Voice Checkout
                </h4>
                <Badge variant="secondary">Powered by Wallaby AI</Badge>
              </div>
              <p className="text-sm text-gray-600 mb-3">
                Say "Complete my order" to checkout with your saved payment method
              </p>
              <Button
                className={`w-full ${isVoiceActive ? "bg-red-500 hover:bg-red-600 animate-pulse" : ""}`}
                onClick={handleVoiceCheckout}
                disabled={isVoiceActive}
              >
                {isVoiceActive ? (
                  <>
                    <Mic className="w-4 h-4 mr-2" />
                    Listening... Say "Complete my order"
                  </>
                ) : (
                  <>
                    <Mic className="w-4 h-4 mr-2" />
                    Start Voice Checkout
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {/* One-Tap Checkout */}
          <Card className="border-green-200 bg-green-50">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-semibold flex items-center gap-2">
                  <Zap className="w-4 h-4" />
                  One-Tap Checkout
                </h4>
                <Badge variant="secondary">Instant</Badge>
              </div>
              <p className="text-sm text-gray-600 mb-3">Use your saved payment method and delivery address</p>
              <Button className="w-full bg-green-600 hover:bg-green-700" onClick={handleQuickCheckout}>
                <Zap className="w-4 h-4 mr-2" />
                Complete Order - ${total.toFixed(2)}
              </Button>
            </CardContent>
          </Card>

          {/* Traditional Checkout */}
          <Card>
            <CardContent className="p-4">
              <h4 className="font-semibold flex items-center gap-2 mb-3">
                <CreditCard className="w-4 h-4" />
                Traditional Checkout
              </h4>
              <div className="space-y-3">
                <Input placeholder="Card Number" />
                <div className="grid grid-cols-2 gap-3">
                  <Input placeholder="MM/YY" />
                  <Input placeholder="CVV" />
                </div>
                <Button variant="outline" className="w-full bg-transparent">
                  Complete Order
                </Button>
              </div>
            </CardContent>
          </Card>
        </CardContent>
      </Card>

      {/* Checkout Features */}
      <Card>
        <CardHeader>
          <CardTitle>Frictionless Features</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <h4 className="font-semibold">Voice Commerce</h4>
              <p className="text-sm text-gray-600">Complete purchases with natural voice commands</p>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold">Predictive Reordering</h4>
              <p className="text-sm text-gray-600">AI suggests when to reorder essentials based on usage patterns</p>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold">One-Tap Checkout</h4>
              <p className="text-sm text-gray-600">Instant checkout with saved payment methods</p>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold">Smart Bundling</h4>
              <p className="text-sm text-gray-600">Automatic discounts for frequently bought together items</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
