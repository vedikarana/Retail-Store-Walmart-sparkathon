"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Star, MapPin, TrendingUp, Clock, ShoppingBag, Heart } from "lucide-react"

const personalizedProducts = [
  {
    id: 1,
    name: "Modern 3-Seat Sofa",
    price: 449.99,
    originalPrice: 599.99,
    image: "/placeholder.svg?height=200&width=200",
    rating: 4.5,
    reviews: 234,
    reason: "Perfect for your small living room",
    category: "Furniture",
    inStock: true,
  },
  {
    id: 2,
    name: "Winter Jacket - No Boundaries",
    price: 29.99,
    image: "/placeholder.svg?height=200&width=200",
    rating: 4.2,
    reviews: 156,
    reason: "Cold weather alert in your area",
    category: "Clothing",
    inStock: true,
  },
  {
    id: 3,
    name: "Tide Laundry Detergent",
    price: 12.97,
    image: "/placeholder.svg?height=200&width=200",
    rating: 4.8,
    reviews: 1024,
    reason: "Time to reorder - running low",
    category: "Essentials",
    inStock: true,
    predictive: true,
  },
]

const trendingCategories = [
  { name: "Winter Essentials", growth: "+25%", icon: "❄️" },
  { name: "Home Decor", growth: "+18%", icon: "🏠" },
  { name: "Gaming", growth: "+32%", icon: "🎮" },
  { name: "Beauty", growth: "+15%", icon: "💄" },
]

export function PersonalizedDashboard() {
  const [location] = useState("Toronto, Canada")
  const [weather] = useState("Cold Snap - 15°C")

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <Card className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
        <CardHeader>
          <CardTitle className="text-2xl">Welcome back, Sarah! 👋</CardTitle>
          <CardDescription className="text-blue-100">
            Your personalized shopping experience powered by Wallaby AI
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4 text-sm">
            <div className="flex items-center gap-1">
              <MapPin className="w-4 h-4" />
              {location}
            </div>
            <div className="flex items-center gap-1">
              <Clock className="w-4 h-4" />
              {weather}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Trending Categories */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5" />
            Trending in Your Area
          </CardTitle>
          <CardDescription>Popular categories based on local trends and weather</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {trendingCategories.map((category, index) => (
              <div
                key={index}
                className="text-center p-4 rounded-lg bg-gray-50 hover:bg-gray-100 transition-colors cursor-pointer"
              >
                <div className="text-2xl mb-2">{category.icon}</div>
                <h3 className="font-medium">{category.name}</h3>
                <Badge variant="secondary" className="mt-1 bg-green-100 text-green-800">
                  {category.growth}
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Personalized Recommendations */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Heart className="w-5 h-5" />
            Recommended for You
          </CardTitle>
          <CardDescription>AI-curated products based on your preferences and context</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {personalizedProducts.map((product) => (
              <Card key={product.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="relative">
                  <img
                    src={product.image || "/placeholder.svg"}
                    alt={product.name}
                    className="w-full h-48 object-cover"
                  />
                  {product.predictive && (
                    <Badge className="absolute top-2 left-2 bg-orange-500">Predictive Reorder</Badge>
                  )}
                  {product.originalPrice && (
                    <Badge className="absolute top-2 right-2 bg-red-500">
                      Save ${(product.originalPrice - product.price).toFixed(2)}
                    </Badge>
                  )}
                </div>
                <CardContent className="p-4">
                  <h3 className="font-semibold mb-2">{product.name}</h3>
                  <div className="flex items-center gap-2 mb-2">
                    <div className="flex items-center">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-4 h-4 ${i < Math.floor(product.rating) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"}`}
                        />
                      ))}
                    </div>
                    <span className="text-sm text-gray-600">({product.reviews})</span>
                  </div>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-xl font-bold">${product.price}</span>
                    {product.originalPrice && (
                      <span className="text-sm text-gray-500 line-through">${product.originalPrice}</span>
                    )}
                  </div>
                  <p className="text-sm text-blue-600 mb-3">{product.reason}</p>
                  <div className="flex gap-2">
                    <Button className="flex-1">Add to Cart</Button>
                    <Button variant="outline" size="icon">
                      <Heart className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5" />
            Quick Actions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Button variant="outline" className="h-16 flex-col gap-2 bg-transparent">
              <span className="text-lg">🛒</span>
              Reorder Essentials
            </Button>
            <Button variant="outline" className="h-16 flex-col gap-2 bg-transparent">
              <span className="text-lg">📱</span>
              Try AR View
            </Button>
            <Button variant="outline" className="h-16 flex-col gap-2 bg-transparent">
              <span className="text-lg">🎮</span>
              Virtual Shopping
            </Button>
            <Button variant="outline" className="h-16 flex-col gap-2 bg-transparent">
              <span className="text-lg">🎤</span>
              Voice Search
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
