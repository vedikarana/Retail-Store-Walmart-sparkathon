"use client"

import { useState } from "react"
import { VoiceAssistant } from "@/components/voice-assistant"
import { ARVisualization } from "@/components/ar-visualization"
import { PersonalizedDashboard } from "@/components/personalized-dashboard"
import { VirtualShopping } from "@/components/virtual-shopping"
import { CheckoutFlow } from "@/components/checkout-flow"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Sparkles, ShoppingCart, Headphones, Eye, Gamepad2, CreditCard } from "lucide-react"

export default function AdaptiveShoppingCompanion() {
  const [activeFeature, setActiveFeature] = useState("dashboard")

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-yellow-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Adaptive Shopping Companion</h1>
                <p className="text-sm text-gray-600">Walmart Sparkathon 2025 - Reinvent the Shopping Experience</p>
              </div>
            </div>
            <Badge variant="secondary" className="bg-blue-100 text-blue-800">
              AI + AR Powered
            </Badge>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeFeature} onValueChange={setActiveFeature} className="space-y-6">
          <TabsList className="grid w-full grid-cols-6 lg:w-fit lg:grid-cols-6">
            <TabsTrigger value="dashboard" className="flex items-center gap-2">
              <ShoppingCart className="w-4 h-4" />
              <span className="hidden sm:inline">Dashboard</span>
            </TabsTrigger>
            <TabsTrigger value="voice" className="flex items-center gap-2">
              <Headphones className="w-4 h-4" />
              <span className="hidden sm:inline">Voice</span>
            </TabsTrigger>
            <TabsTrigger value="ar" className="flex items-center gap-2">
              <Eye className="w-4 h-4" />
              <span className="hidden sm:inline">AR View</span>
            </TabsTrigger>
            <TabsTrigger value="virtual" className="flex items-center gap-2">
              <Gamepad2 className="w-4 h-4" />
              <span className="hidden sm:inline">Virtual</span>
            </TabsTrigger>
            <TabsTrigger value="checkout" className="flex items-center gap-2">
              <CreditCard className="w-4 h-4" />
              <span className="hidden sm:inline">Checkout</span>
            </TabsTrigger>
            <TabsTrigger value="demo" className="flex items-center gap-2">
              <Sparkles className="w-4 h-4" />
              <span className="hidden sm:inline">Demo</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="space-y-6">
            <PersonalizedDashboard />
          </TabsContent>

          <TabsContent value="voice" className="space-y-6">
            <VoiceAssistant />
          </TabsContent>

          <TabsContent value="ar" className="space-y-6">
            <ARVisualization />
          </TabsContent>

          <TabsContent value="virtual" className="space-y-6">
            <VirtualShopping />
          </TabsContent>

          <TabsContent value="checkout" className="space-y-6">
            <CheckoutFlow />
          </TabsContent>

          <TabsContent value="demo" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5" />
                  Complete Demo Flow
                </CardTitle>
                <CardDescription>Experience the full Adaptive Shopping Companion journey</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  <Card className="p-4">
                    <h3 className="font-semibold mb-2">1. Voice Discovery</h3>
                    <p className="text-sm text-gray-600">
                      Start with "Find me a couch for my small living room under $500"
                    </p>
                  </Card>
                  <Card className="p-4">
                    <h3 className="font-semibold mb-2">2. AR Visualization</h3>
                    <p className="text-sm text-gray-600">
                      See how products look in your space with interactive hotspots
                    </p>
                  </Card>
                  <Card className="p-4">
                    <h3 className="font-semibold mb-2">3. Virtual Shopping</h3>
                    <p className="text-sm text-gray-600">Shop in Roblox/ZEPETO and buy real-world items</p>
                  </Card>
                  <Card className="p-4">
                    <h3 className="font-semibold mb-2">4. Predictive Reorder</h3>
                    <p className="text-sm text-gray-600">AI suggests when to reorder essentials</p>
                  </Card>
                  <Card className="p-4">
                    <h3 className="font-semibold mb-2">5. One-Tap Checkout</h3>
                    <p className="text-sm text-gray-600">Frictionless payment with voice confirmation</p>
                  </Card>
                  <Card className="p-4">
                    <h3 className="font-semibold mb-2">6. Personalized Content</h3>
                    <p className="text-sm text-gray-600">Dynamic homepage based on preferences and context</p>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
